# DBMS-Movie-Ticket-Booking-System
This repository contains the source code for Online Movie Ticket Booking System, which was a Mini Project for Database Management System (DBMS). 

![UI](Screenshots/OMTBS.PNG)
